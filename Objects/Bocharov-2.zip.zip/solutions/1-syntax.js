export const getObject = () => {
  let obj = {
  "files": [
  "src/objects.js"
  ],
  "config": true
  };
  
  return obj;
  };
  
  export default getObject;